File Data Encryption System (GUI Version)
-----------------------------------------

This is a standalone offline encryption/decryption application.

How to Use:
1. Double click EncryptionGUI.exe
2. Browse for the input file you wish to encrypt or decrypt.
3. Browse for where you want the output file to be saved.
4. Select your preferred method (XOR or Shift).
5. Enter a key (or generate one) for XOR, or specify a Shift value.
6. Click Encrypt or Decrypt!

Note: No installation is required. This executable can be shared with anyone running Windows.
